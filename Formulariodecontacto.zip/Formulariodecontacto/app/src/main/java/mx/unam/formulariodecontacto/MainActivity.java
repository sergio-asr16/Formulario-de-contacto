package mx.unam.formulariodecontacto;


import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public TextInputEditText tietNombre, tietTelefono, tietEmail, tietDescripcion;
    public DatePicker tietFechaN;
    public Button Siguiente;

    public int day, month, year;
    public String stringDay, stringMonth, stringYear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bundle parametrosReturn = getIntent().getExtras();

        tietNombre = (TextInputEditText) findViewById(R.id.iNombre);
        tietFechaN = (DatePicker) findViewById(R.id.iFecha);
        tietTelefono = (TextInputEditText) findViewById(R.id.iTelefono);
        tietEmail = (TextInputEditText) findViewById(R.id.iEmail);
        tietDescripcion = (TextInputEditText) findViewById(R.id.iDescripcion);
        Siguiente = (Button) findViewById(R.id.bSiguiente);

    // Si los valores se encuentran en blanco, esto cachara los datos de la actividad "Confirmacion, para que puedan ser mostrados nevamente
        if (parametrosReturn != null){

            String nombreCompleto = parametrosReturn.getString(getResources().getString(R.string.tvNombre));
            String _day = parametrosReturn.getString("day");
            String _month = parametrosReturn.getString("month");
            String _year = parametrosReturn.getString("year");
            String telefono = parametrosReturn.getString(getResources().getString(R.string.tvTelefono));
            String email = parametrosReturn.getString(getResources().getString(R.string.tvEmail));
            String descripcion = parametrosReturn.getString(getResources().getString(R.string.tvDescripcion));

    //Una vez cachados los parametros se asignan a las variables de "tiet" para que puedan ser mostradas nuevamente
            tietNombre.setText(nombreCompleto);
            tietFechaN.init(Integer.parseInt(_year), Integer.parseInt(_month), Integer.parseInt(_day), null);
            tietTelefono.setText(telefono);
            tietEmail.setText(email);
            tietDescripcion.setText(descripcion);

        }
            Siguiente.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        day = tietFechaN.getDayOfMonth();
        month = tietFechaN.getMonth()+1;
        year = tietFechaN.getYear();

        stringDay = String.valueOf(day);
        stringMonth = String.valueOf(month);
        stringYear = String.valueOf(year);

        Intent intent = new Intent(this, Confirmacion.class);
            intent.putExtra(getResources().getString(R.string.nombreCompleto), tietNombre.getText().toString());
            intent.putExtra("day", stringDay);
            intent.putExtra("month", stringMonth);
            intent.putExtra("year", stringYear);
            intent.putExtra(getResources().getString(R.string.telefono), tietTelefono.getText().toString());
            intent.putExtra(getResources().getString(R.string.email),tietEmail.getText().toString());
            intent.putExtra(getResources().getString(R.string.descripcion),tietDescripcion.getText().toString());
            startActivity(intent);
    }
}
