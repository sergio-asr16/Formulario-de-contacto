package mx.unam.formulariodecontacto;

import android.support.design.widget.TextInputEditText;
import android.widget.DatePicker;

/**
 * Created by USER on 6/15/2017.
 */

public class Datos {

    public TextInputEditText nombre;
    public DatePicker fecha;
    public TextInputEditText telefono;
    public TextInputEditText email;
    public TextInputEditText descripcion;

    public Datos(TextInputEditText nombre, DatePicker fecha, TextInputEditText telefono, TextInputEditText email, TextInputEditText descripcion) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.telefono = telefono;
        this.email = email;
        this.descripcion = descripcion;
    }

    public TextInputEditText getNombre() {
        return nombre;
    }

    public void setNombre(TextInputEditText nombre) {
        this.nombre = nombre;
    }

    public DatePicker getFecha() {
        return fecha;
    }

    public void setFecha(DatePicker fecha) {
        this.fecha = fecha;
    }

    public TextInputEditText getTelefono() {
        return telefono;
    }

    public void setTelefono(TextInputEditText telefono) {
        this.telefono = telefono;
    }

    public TextInputEditText getEmail() {
        return email;
    }

    public void setEmail(TextInputEditText email) {
        this.email = email;
    }

    public TextInputEditText getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(TextInputEditText descripcion) {
        this.descripcion = descripcion;
    }
}
