package mx.unam.formulariodecontacto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class Confirmacion extends AppCompatActivity implements View.OnClickListener {

    public TextView _nombre, _fechaN, _telefono, _email, _descripcion;
    public String _day, _month, _year;
    public Button EditarDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmacion);

        Bundle parametros = getIntent().getExtras();

        String nombreCompleto = parametros.getString(getResources().getString(R.string.nombreCompleto));
        String day = parametros.getString("day");
        String month = parametros.getString("month");
        String year = parametros.getString("year");
        String fechaN= day+"/"+month+"/"+year;
        String telefono = parametros.getString(getResources().getString(R.string.telefono));
        String email = parametros.getString(getResources().getString(R.string.email));
        String descripcion = parametros.getString(getResources().getString(R.string.descripcion));

        //Se guardan los datos cachados en variables con diferente nombre para que puedan ser manipulos y regresados.

        _nombre=(TextView)findViewById(R.id.tvNombre);
        _fechaN=(TextView)findViewById(R.id.tvFecha);
        _telefono=(TextView)findViewById(R.id.tvTelefono);
        _email=(TextView)findViewById(R.id.tvEmail);
        _descripcion=(TextView)findViewById(R.id.tvDescripcion);
        _day=day;
        _month=String.valueOf(Integer.parseInt(month)-1);;
        _year=year;
         EditarDatos = (Button) findViewById(R.id.bEditarDatos);

        _nombre.setText(nombreCompleto);
        _fechaN.setText(fechaN);
        _telefono.setText(telefono);
        _email.setText(email);
        _descripcion.setText(descripcion);

    EditarDatos.setOnClickListener(this);

    }


    @Override

    public void onClick(View v) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(getResources().getString(R.string.tvNombre), _nombre.getText());
        intent.putExtra("day", _day);
        intent.putExtra("month",_month);
        intent.putExtra("year",_year);
        intent.putExtra(getResources().getString(R.string.tvTelefono),_telefono.getText());
        intent.putExtra(getResources().getString(R.string.tvEmail), _email.getText());
        intent.putExtra(getResources().getString(R.string.tvDescripcion), _descripcion.getText());
        startActivity(intent);
    }
}
